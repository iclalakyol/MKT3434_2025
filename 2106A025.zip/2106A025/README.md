# ⚙️ MKT3434_2025

**MKT3434 Course of Dept. Mechatronics Eng. at YTU instructed by Ertugrul Bayraktar**

---

## 🚀 Overview

This repository provides a base GUI framework for students to develop and integrate machine learning methods. The GUI is built using PyQt6 and supports various classical machine learning and deep learning techniques. Students will extend this GUI by adding necessary functionalities over time.
  This GUI has been extended to include cross-validation support, dimensionality reduction methods (PCA, LDA, t-SNE, UMAP), clustering evaluation metrics (Silhouette Score), and dynamic projection visualization.
  The current version of the GUI includes several enhancements such as preprocessing strategies for handling missing values (mean imputation, interpolation, and forward/backward fill), support for custom loss function selection (MSE, MAE, and Huber for regression; Cross-Entropy and Hinge Loss for classification), configurable Support Vector Machine and Support Vector Regression (SVC/SVR) implementations with selectable kernel types, C, degree, and epsilon parameters, an extended Gaussian Naive Bayes model with var_smoothing and customizable prior probabilities, and automatic visualization of prediction results along with detailed performance metrics.

---

## 📚 Long-Term Homework Instructions

Students are required to modify and enhance this GUI incrementally every three weeks. The objective is to build a fully functional and improved machine learning GUI.

### 🎯 Key Requirements:

*   **Insert Necessary Methods:** Integrate missing machine learning methods within the provided GUI framework.
*   **Enhance the GUI:** The default interface is provided, but students are encouraged to improve usability and design.
*   **Ensure Data and Method Appropriateness:** The datasets and algorithms should be compatible within the GUI structure.
*   **Implement Training and Testing Processes:** Correctly implement model training and evaluation workflows.
*   **Regular Submissions:** Submit updates every three weeks through Google Classroom for this course.

---
✅ Implemented Features (as of Week 11 / 2 May 2025):

✅ Train/Validation/Test Split configuration via GUI (split_spin and val_split_spin) for ratios like 70-15-15

✅ PCA: User-defined n_components, whiten option, and explained variance visualization

✅ LDA: Supervised dimensionality reduction with 1D projection and class visualization

✅ t-SNE: Interactive projections with perplexity and n_components control (1D/2D/3D support)

✅ UMAP: Faster alternative to t-SNE with configurable n_neighbors, min_dist, and dimensions

✅ KMeans: Elbow method for optimal k and Plotly-based clustering visualization

✅ Silhouette Score: Evaluation metric for clustering quality (automatically displayed after KMeans)

✅ Cross-Validation: K-Fold support with selectable metrics (Accuracy, MSE, RMSE)

✅ Neural Network Builder: Dynamic layer addition, training graph visualization

✅  A dropdown to choose missing data handling methods under the "Data Management" section.

✅ A loss function selection panel under the "Classical ML" tab.

✅ Additional training logic in `train_model()` for dynamic loss evaluation.

✅Extended `Support Vector Machine` block to train both SVC and SVR based on dataset type.

✅ Modified `Naive Bayes` to support `var_smoothing` and `priors` (Uniform or Custom).

✅ Auto-update of results on the right panel including visual plots and metric logs.

✅ Deep Learning Tab – Extended Features Implemented
The Deep Learning tab of the GUI has been extended to fully support neural network configuration, training, and evaluation as specified in the long-term homework instructions.

🔧 Architecture Features (Under "Deep Learning" Tab)
✅ Configurable Hidden Layers
Users can dynamically add Dense layers with user-defined number of units (e.g., 128 → 64 → 32) and activation functions (ReLU, Sigmoid, Tanh, Softmax) via dialog.

✅ Add Convolutional & Pooling Layers

Conv2D, MaxPooling2D, and Flatten layers can be added with parameters like filter size, kernel shape.

Default configuration works seamlessly for image datasets like MNIST.

✅ RNN Layer Support

GUI allows adding LSTM and GRU layers with options for units, activation, and return_sequences.

The input data is automatically reshaped (e.g., (samples, 1, features)) for RNN compatibility.

✅ Dynamic Layer Management

Layers can be added dynamically from the GUI.

GUI lists all added layers with their parameters (in a scrollable QLabel).

⚙️ Training Infrastructure
✅ Optimizers
Users can choose from Adam, SGD, and RMSprop, selectable from a dropdown.

✅ Regularization Options

Each Dense layer supports user-defined Dropout Rate and L2 regularization strength (λ).

These are set via input dialogs when adding layers.

✅ Validation Monitoring

Validation loss is monitored during training (validation_data=(X_test, y_test) in .fit()).

Training history is stored and used for plotting.

✅ Training Curves Visualization

Plots for training vs. validation accuracy and loss are shown live in a matplotlib canvas.

✅ Final Test Metrics Reported

After training, the model is evaluated on test data and the Accuracy, F1-score, and Classification Report are displayed in a QMessageBox popup.

✅ Model Save/Load

Supports saving models as .h5

Load previously trained models and recompile for prediction.

🧠 Pretrained Model Support
✅ VGG16 and ResNet50 Integration

Users can select VGG16 or ResNet50 from a dropdown.

MNIST data is resized from (28, 28, 1) to (32, 32, 3) and converted from grayscale to RGB using tf.image.grayscale_to_rgb() for compatibility.

✅ Custom Fine-Tuning

Fine-tuning is possible by combining pretrained base with custom classifier layers.


## 🤝 Repository and Collaboration

Students should fork this repository and develop their versions.

Regular commits and documentation updates are expected.

---

## 🏁 Getting Started


### ⚙️ Prerequisites:

Ensure you have the following installed:

*   Python 3.8+

### 📦 Required dependencies:

```bash
pip install numpy pandas matplotlib PyQt6 scikit-learn tensorflow torch torchvision torchaudio opencv-python opencv-contrib-python scipy fastai kornia
pip install numpy pandas matplotlib PyQt6 scikit-learn tensorflow torch torchvision torchaudio opencv-python opencv-contrib-python scipy fastai kornia
pip install plotly umap-learn

Example Workflows

Example usage scenarios tested in the extended GUI:
---

## 🧠 Example Use Case:

1. Load a dataset (e.g., Iris or Breast Cancer)
2. Choose a missing data strategy (e.g., mean imputation)
3. Select a model (e.g., Support Vector Machine) and set kernel/C/epsilon
4. Choose a loss function suitable to the task
5. Train the model and view metrics and visualization in the bottom panel
6. Iris Dataset + PCA + Logistic Regression→ Explained variance plotted + 2D classification visualization
7. Digits Dataset + t-SNE (perplexity=30)→ 2D interactive projection using matplotlib and label coloring
8. MNIST + UMAP + KMeans→ Silhouette Score: 0.61 — Visualized using Plotly clusters
9. Breast Cancer + 5-Fold CV (Accuracy)→ Average Accuracy: 96.4%, Std: 0.8%

