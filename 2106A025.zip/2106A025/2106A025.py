import sys
import numpy as np
import pandas as pd
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QTabWidget, QPushButton, QLabel, 
                           QComboBox, QFileDialog, QSpinBox, QDoubleSpinBox,
                           QGroupBox, QScrollArea, QTextEdit, QStatusBar,
                           QProgressBar, QCheckBox, QGridLayout, QMessageBox,
                           QDialog, QLineEdit)
from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn import datasets, preprocessing, model_selection
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, mean_squared_error, confusion_matrix
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers
from mpl_toolkits.mplot3d import Axes3D
from sklearn.metrics import mean_absolute_error, log_loss, hinge_loss



class MLCourseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Machine Learning Course GUI")
        self.setGeometry(100, 100, 1400, 800)
        
        # Initialize main widget and layout
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        
        # Initialize data containers
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.current_model = None
        
        # Neural network configuration
        self.layer_config = []
        
        # Create components
        self.create_data_section()
        self.create_tabs()
        self.create_visualization()
        self.create_status_bar()
    def load_dataset(self):
        """Load selected dataset"""
        try:
            dataset_name = self.dataset_combo.currentText()
            
            if dataset_name == "Load Custom Dataset":
                return
            
            # Load selected dataset
            if dataset_name == "Iris Dataset":
                data = datasets.load_iris()
            elif dataset_name == "Breast Cancer Dataset":
                data = datasets.load_breast_cancer()
            elif dataset_name == "Digits Dataset":
                data = datasets.load_digits()
            elif dataset_name == "Boston Housing Dataset":
                data = datasets.load_boston()
            elif dataset_name == "MNIST Dataset":
                (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
                self.X_train, self.X_test = X_train, X_test
                self.y_train, self.y_test = y_train, y_test
                self.status_bar.showMessage(f"Loaded {dataset_name}")
                return
            

            
            # Split data
            test_size = self.split_spin.value()
            self.X_train, self.X_test, self.y_train, self.y_test = \
                model_selection.train_test_split(data.data, data.target, 
                                              test_size=test_size, 
                                              random_state=42)
            X = data.data
            y = data.target
            X, y = self.apply_missing_data_strategy(X, y)

            
            #Valid split 
            val_ratio = self.val_split_spin.value() / (1.0 - self.split_spin.value())
            X_temp, y_temp = self.X_train, self.y_train  # Define temporary training data
            self.X_train, self.X_val, self.y_train, self.y_val = model_selection.train_test_split(
                X_temp, y_temp, test_size=val_ratio, random_state=42
            )
            
            # Apply scaling if selected
            self.apply_scaling()
            
            self.status_bar.showMessage(f"Loaded {dataset_name}")
            
        except Exception as e:
            self.show_error(f"Error loading dataset: {str(e)}")
    def apply_missing_data_strategy(self, X, y):
        """Eksik veri stratejisini uygular"""
        strategy = self.missing_data_combo.currentText()
        df = pd.DataFrame(X)

        if strategy == "Mean Imputation":
            df.fillna(df.mean(), inplace=True)
        elif strategy == "Interpolation":
            df.interpolate(method='linear', inplace=True)
        elif strategy == "Forward Fill":
            df.fillna(method='ffill', inplace=True)
        elif strategy == "Backward Fill":
            df.fillna(method='bfill', inplace=True)

        return df.values, y

    
    def load_custom_data(self):
        """Load custom dataset from CSV file"""
        try:
            file_name, _ = QFileDialog.getOpenFileName(
                self,
                "Load Dataset",
                "",
                "CSV files (*.csv)"
            )
            
            if file_name:
                # Load data
                data = pd.read_csv(file_name)
                
                # Ask user to select target column
                target_col = self.select_target_column(data.columns)
                
                if target_col:
                    X = data.drop(target_col, axis=1)
                    y = data[target_col]

                    x, y = self.apply_missing_data_strategy(x, y)

                    
                    # Split data
                    test_size = self.split_spin.value()
                    self.X_train, self.X_test, self.y_train, self.y_test = \
                        model_selection.train_test_split(X, y, 
                                                      test_size=test_size, 
                                                      random_state=42)
                    
                    # Valid split
                    val_ratio = self.val_split_spin.value() / (1.0 - self.split_spin.value())
                    X_temp, y_temp = self.X_train, self.y_train  # Define temporary training data
                    self.X_train, self.X_val, self.y_train, self.y_val = model_selection.train_test_split(
                        X_temp, y_temp, test_size=val_ratio, random_state=42
                    )   

                    # Apply scaling if selected
                    self.apply_scaling()
                    
                    self.status_bar.showMessage(f"Loaded custom dataset: {file_name}")
                    
        except Exception as e:
            self.show_error(f"Error loading custom dataset: {str(e)}")
    
    def select_target_column(self, columns):
        """Dialog to select target column from dataset"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Target Column")
        layout = QVBoxLayout(dialog)
        
        combo = QComboBox()
        combo.addItems(columns)
        layout.addWidget(combo)
        
        btn = QPushButton("Select")
        btn.clicked.connect(dialog.accept)
        layout.addWidget(btn)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return combo.currentText()
        return None
    
    def apply_scaling(self):
        """Apply selected scaling method to the data"""
        scaling_method = self.scaling_combo.currentText()
        
        if scaling_method != "No Scaling":
            try:
                if scaling_method == "Standard Scaling":
                    scaler = preprocessing.StandardScaler()
                elif scaling_method == "Min-Max Scaling":
                    scaler = preprocessing.MinMaxScaler()
                elif scaling_method == "Robust Scaling":
                    scaler = preprocessing.RobustScaler()
                
                self.X_train = scaler.fit_transform(self.X_train)
                if hasattr(self, "X_val") and self.X_val is not None:
                    self.X_val = scaler.transform(self.X_val)
                self.X_test = scaler.transform(self.X_test)

                
            except Exception as e:
                self.show_error(f"Error applying scaling: {str(e)}")
    def create_data_section(self):
        """Create the data loading and preprocessing section"""
        data_group = QGroupBox("Data Management")
        data_layout = QHBoxLayout()
        
        # Dataset selection
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems([
            "Load Custom Dataset",
            "Iris Dataset",
            "Breast Cancer Dataset",
            "Digits Dataset",
            "Boston Housing Dataset",
            "MNIST Dataset"
        ])
        self.dataset_combo.currentIndexChanged.connect(self.load_dataset)
        
        # Data loading button
        self.load_btn = QPushButton("Load Data")
        self.load_btn.clicked.connect(self.load_custom_data)
        
        # Preprocessing options
        self.scaling_combo = QComboBox()
        self.scaling_combo.addItems([
            "No Scaling",
            "Standard Scaling",
            "Min-Max Scaling",
            "Robust Scaling"
        ])
        
        # Train-test split options
        self.split_spin = QDoubleSpinBox()
        self.split_spin.setRange(0.1, 0.9)
        self.split_spin.setValue(0.2)
        self.split_spin.setSingleStep(0.1)

        # Validation split options
        self.val_split_spin = QDoubleSpinBox()
        self.val_split_spin.setRange(0.0, 0.9)
        self.val_split_spin.setValue(0.15)
        self.val_split_spin.setSingleStep(0.05)

        
        # Add widgets to layout
        data_layout.addWidget(QLabel("Dataset:"))
        data_layout.addWidget(self.dataset_combo)
        data_layout.addWidget(self.load_btn)
        data_layout.addWidget(QLabel("Scaling:"))
        data_layout.addWidget(self.scaling_combo)
        data_layout.addWidget(QLabel("Test Split:"))
        data_layout.addWidget(self.split_spin)
        data_layout.addWidget(QLabel("Validation Split:"))
        data_layout.addWidget(self.val_split_spin)

        # Eksik veri stratejisi
        self.missing_data_combo = QComboBox()
        self.missing_data_combo.addItems([
            "None",
            "Mean Imputation",
            "Interpolation",
            "Forward Fill",
            "Backward Fill"
        ])
        data_layout.addWidget(QLabel("Missing Data Strategy:"))
        data_layout.addWidget(self.missing_data_combo)


        
        data_group.setLayout(data_layout)
        self.layout.addWidget(data_group)
    
    def create_tabs(self):
        """Create tabs for different ML topics"""
        self.tab_widget = QTabWidget()
        
        # Create individual tabs
        tabs = [
            ("Classical ML", self.create_classical_ml_tab),
            ("Deep Learning", self.create_deep_learning_tab),
            ("Dimensionality Reduction", self.create_dim_reduction_tab),
            ("Reinforcement Learning", self.create_rl_tab),

        ]
        
        for tab_name, create_func in tabs:
            scroll = QScrollArea()
            tab_widget = create_func()
            scroll.setWidget(tab_widget)
            scroll.setWidgetResizable(True)
            self.tab_widget.addTab(scroll, tab_name)
        
        self.layout.addWidget(self.tab_widget)
    
    def create_classical_ml_tab(self):
        """Create the classical machine learning algorithms tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Regression section
        regression_group = QGroupBox("Regression")
        regression_layout = QVBoxLayout()
        
        # Linear Regression
        lr_group = self.create_algorithm_group(
            "Linear Regression",
            {"fit_intercept": "checkbox",
             "normalize": "checkbox"}
        )
        regression_layout.addWidget(lr_group)
        
        # Logistic Regression
        logistic_group = self.create_algorithm_group(
            "Logistic Regression",
            {"C": "double",
             "max_iter": "int",
             "multi_class": ["ovr", "multinomial"]}
        )
        regression_layout.addWidget(logistic_group)
        
        regression_group.setLayout(regression_layout)
        layout.addWidget(regression_group, 0, 0)
        
        # Classification section
        classification_group = QGroupBox("Classification")
        classification_layout = QVBoxLayout()
        
        # Naive Bayes
        nb_group = self.create_algorithm_group(
            "Naive Bayes",
            {
                "var_smoothing": "double",
                "priors": ["Uniform", "Custom"]
            }
        )
        classification_layout.addWidget(nb_group)
        
        # SVM / SVR için kernel ve hiperparametreler
        svm_group = self.create_algorithm_group(
            "Support Vector Machine",
            {"C": "double",
            "kernel": ["linear", "rbf", "poly"],
            "degree": "int",
            "epsilon": "double"}  # SVR için
        )
        classification_layout.addWidget(svm_group)

        # Decision Trees
        dt_group = self.create_algorithm_group(
            "Decision Tree",
            {"max_depth": "int",
             "min_samples_split": "int",
             "criterion": ["gini", "entropy"]}
        )
        classification_layout.addWidget(dt_group)
        
        # Random Forest
        rf_group = self.create_algorithm_group(
            "Random Forest",
            {"n_estimators": "int",
             "max_depth": "int",
             "min_samples_split": "int"}
        )
        classification_layout.addWidget(rf_group)
        
        # KNN
        knn_group = self.create_algorithm_group(
            "K-Nearest Neighbors",
            {"n_neighbors": "int",
             "weights": ["uniform", "distance"],
             "metric": ["euclidean", "manhattan"]}
        )
        classification_layout.addWidget(knn_group)
        
        classification_group.setLayout(classification_layout)
        layout.addWidget(classification_group, 0, 1)

        # === LOSS FUNCTION SELECTION ===
        loss_group = QGroupBox("Loss Function")
        loss_layout = QVBoxLayout()

        # Regression Loss
        self.regression_loss_combo = QComboBox()
        self.regression_loss_combo.addItems(["MSE", "MAE", "Huber"])
        loss_layout.addWidget(QLabel("Regression Loss Function:"))
        loss_layout.addWidget(self.regression_loss_combo)

        # Classification Loss
        self.classification_loss_combo = QComboBox()
        self.classification_loss_combo.addItems(["Cross-Entropy", "Hinge"])
        loss_layout.addWidget(QLabel("Classification Loss Function:"))
        loss_layout.addWidget(self.classification_loss_combo)

        loss_group.setLayout(loss_layout)
        layout.addWidget(loss_group, 1, 0)

        
        return widget
    
    def create_dim_reduction_tab(self):
        """Create the dimensionality reduction tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # K-Means section
        kmeans_group = QGroupBox("K-Means Clustering")
        kmeans_layout = QVBoxLayout()
        
        kmeans_params = self.create_algorithm_group(
            "K-Means Parameters",
            {"n_clusters": "int",
             "max_iter": "int",
             "n_init": "int",
             "max_k_for_elbow": "int" }
        )
        kmeans_layout.addWidget(kmeans_params)

        elbow_btn = QPushButton("Run Elbow Method")
        elbow_btn.clicked.connect(self.run_elbow_method)
        kmeans_layout.addWidget(elbow_btn)

        
        kmeans_group.setLayout(kmeans_layout)
        layout.addWidget(kmeans_group, 0, 0)
        
        # PCA section
        pca_group = QGroupBox("Principal Component Analysis")
        pca_layout = QVBoxLayout()
        
        pca_groupbox = self.create_algorithm_group(
            "PCA Parameters",
            {"n_components": "int",
             "whiten": "checkbox"}
        )
        pca_layout.addWidget(pca_groupbox)
        
        pca_group.setLayout(pca_layout)
        layout.addWidget(pca_group, 0, 1)

        #LDA section
        lda_group = QGroupBox("Linear Discriminant Analysis")
        lda_layout = QVBoxLayout()

        lda_groupbox = self.create_algorithm_group(
            "LDA Parameters",
            {"n_components": "int"}
        )
        lda_layout.addWidget(lda_groupbox)

        lda_group.setLayout(lda_layout)
        layout.addWidget(lda_group, 1, 0)

        # t-SNE section
        tsne_group = QGroupBox("t-SNE")
        tsne_layout = QVBoxLayout()

        tsne_groupbox = self.create_algorithm_group(
            "t-SNE Parameters",
            {
                "n_components": "int",
                "perplexity": "double"
            }
        )
        tsne_layout.addWidget(tsne_groupbox)

        tsne_group.setLayout(tsne_layout)
        layout.addWidget(tsne_group, 1, 1)

        # UMAP section
        umap_group = QGroupBox("UMAP")
        umap_layout = QVBoxLayout()

        umap_groupbox = self.create_algorithm_group(
            "UMAP Parameters",
            {
                "n_neighbors": "int",
                "min_dist": "double",
                "n_components": "int"
            }
        )
        umap_layout.addWidget(umap_groupbox)
        umap_group.setLayout(umap_layout)
        layout.addWidget(umap_group, 2, 1)

        # Cross-Validation section
        cv_group = QGroupBox("Cross-Validation")
        cv_layout = QVBoxLayout()
        cv_metric_layout = QHBoxLayout()
        cv_metric_layout.addWidget(QLabel("Evaluation Metric:"))
        self.cv_metric_combo = QComboBox()
        self.cv_metric_combo.addItems(["Accuracy", "MSE", "RMSE"])
        cv_metric_layout.addWidget(self.cv_metric_combo)
        cv_layout.addLayout(cv_metric_layout)

        # k değeri için SpinBox
        cv_k_layout = QHBoxLayout()
        cv_k_layout.addWidget(QLabel("Number of Folds (k):"))
        self.cv_k_spin = QSpinBox()
        self.cv_k_spin.setRange(2, 20)
        self.cv_k_spin.setValue(5)
        cv_k_layout.addWidget(self.cv_k_spin)
        cv_layout.addLayout(cv_k_layout)

        # Train butonu
        cv_train_btn = QPushButton("Run Cross-Validation")
        cv_train_btn.clicked.connect(self.train_cv)
        cv_layout.addWidget(cv_train_btn)

        cv_group.setLayout(cv_layout)
        layout.addWidget(cv_group, 2, 0)



        
        return widget
    
    def create_rl_tab(self):
        """Create the reinforcement learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Environment selection
        env_group = QGroupBox("Environment")
        env_layout = QVBoxLayout()
        
        self.env_combo = QComboBox()
        self.env_combo.addItems([
            "CartPole-v1",
            "MountainCar-v0",
            "Acrobot-v1"
        ])
        env_layout.addWidget(self.env_combo)
        
        env_group.setLayout(env_layout)
        layout.addWidget(env_group, 0, 0)
        
        # RL Algorithm selection
        algo_group = QGroupBox("RL Algorithm")
        algo_layout = QVBoxLayout()
        
        self.rl_algo_combo = QComboBox()
        self.rl_algo_combo.addItems([
            "Q-Learning",
            "SARSA",
            "DQN"
        ])
        algo_layout.addWidget(self.rl_algo_combo)
        
        algo_group.setLayout(algo_layout)
        layout.addWidget(algo_group, 0, 1)
        
        return widget
    
    def create_visualization(self):
        """Create the visualization section"""
        viz_group = QGroupBox("Visualization")
        viz_layout = QHBoxLayout()
        
        # Create matplotlib figure
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)
        viz_layout.addWidget(self.canvas)
        
        # Metrics display
        self.metrics_text = QTextEdit()
        self.metrics_text.setReadOnly(True)
        viz_layout.addWidget(self.metrics_text)
        
        viz_group.setLayout(viz_layout)
        self.layout.addWidget(viz_group)
    
    def create_status_bar(self):
        """Create the status bar"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Add progress bar
        self.progress_bar = QProgressBar()
        self.status_bar.addPermanentWidget(self.progress_bar)
    
    def create_algorithm_group(self, name, params):
        """Helper method to create algorithm parameter groups"""
        group = QGroupBox(name)
        layout = QVBoxLayout()
        
        # Create parameter inputs
        param_widgets = {}
        for param_name, param_type in params.items():
            param_layout = QHBoxLayout()
            param_layout.addWidget(QLabel(f"{param_name}:"))
            
            if param_type == "int":
                widget = QSpinBox()
                widget.setRange(1, 1000)
            elif param_type == "double":
                widget = QDoubleSpinBox()
                widget.setRange(0.0001, 1000.0)
                widget.setSingleStep(0.1)
            elif param_type == "checkbox":
                widget = QCheckBox()
            elif isinstance(param_type, list):
                widget = QComboBox()
                widget.addItems(param_type)
            
            param_layout.addWidget(widget)
            param_widgets[param_name] = widget
            layout.addLayout(param_layout)
        
        # Add train button
        train_btn = QPushButton(f"Train {name}")
        if name == "PCA Parameters":
            self.pca_widgets = param_widgets
            train_btn.clicked.connect(self.train_pca)
        elif name == "LDA Parameters":
            self.lda_widgets = param_widgets
            train_btn.clicked.connect(self.train_lda)
        elif name == "t-SNE Parameters":
            self.tsne_widgets = param_widgets
            train_btn.clicked.connect(self.train_tsne)
        elif name == "UMAP Parameters":
            self.umap_widgets = param_widgets
            train_btn.clicked.connect(self.train_umap)
        elif name == "Cross-Validation":
            self.cv_k_spin = param_widgets["k"]
            train_btn.clicked.connect(self.train_cv)
        elif name == "K-Means Parameters":
            self.kmeans_widgets = param_widgets
            train_btn.clicked.connect(self.train_kmeans)
                

        else:
            train_btn.clicked.connect(lambda: self.train_model(name, param_widgets))    
        layout.addWidget(train_btn)
        
        group.setLayout(layout)
        return group

    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)
       
    def create_deep_learning_tab(self):
        """Create the deep learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # MLP section
        mlp_group = QGroupBox("Multi-Layer Perceptron")
        mlp_layout = QVBoxLayout()
        
        # Layer configuration
        self.layer_config = []
        layer_btn = QPushButton("Add Layer")
        layer_btn.clicked.connect(self.add_layer_dialog)
        mlp_layout.addWidget(layer_btn)
        
        # Training parameters
        training_params_group = self.create_training_params_group()
        mlp_layout.addWidget(training_params_group)
        
        # Train button
        train_btn = QPushButton("Train Neural Network")
        train_btn.clicked.connect(self.train_neural_network)
        mlp_layout.addWidget(train_btn)
        
        mlp_group.setLayout(mlp_layout)
        layout.addWidget(mlp_group, 0, 0)
        
        # CNN section
        cnn_group = QGroupBox("Convolutional Neural Network")
        cnn_layout = QVBoxLayout()
        
        # CNN architecture controls
        cnn_controls = self.create_cnn_controls()
        cnn_layout.addWidget(cnn_controls)
        
        cnn_group.setLayout(cnn_layout)
        layout.addWidget(cnn_group, 0, 1)
        
        # RNN section
        rnn_group = QGroupBox("Recurrent Neural Network")
        rnn_layout = QVBoxLayout()
        
        # RNN architecture controls
        rnn_controls = self.create_rnn_controls()
        rnn_layout.addWidget(rnn_controls)
        
        rnn_group.setLayout(rnn_layout)
        layout.addWidget(rnn_group, 1, 0)
        
        return widget
    
    def add_layer_dialog(self):
        """Open a dialog to add a neural network layer"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Neural Network Layer")
        layout = QVBoxLayout(dialog)
        
        # Layer type selection
        type_layout = QHBoxLayout()
        type_label = QLabel("Layer Type:")
        type_combo = QComboBox()
        type_combo.addItems(["Dense", "Conv2D", "MaxPooling2D", "Flatten", "Dropout"])
        type_layout.addWidget(type_label)
        type_layout.addWidget(type_combo)
        layout.addLayout(type_layout)
        
        # Parameters input
        params_group = QGroupBox("Layer Parameters")
        params_layout = QVBoxLayout()
        
        # Dynamic parameter inputs based on layer type
        self.layer_param_inputs = {}
        
        def update_params():
            # Clear existing parameter inputs
            for widget in list(self.layer_param_inputs.values()):
                params_layout.removeWidget(widget)
                widget.deleteLater()
            self.layer_param_inputs.clear()
            
            layer_type = type_combo.currentText()
            if layer_type == "Dense":
                units_label = QLabel("Units:")
                units_input = QSpinBox()
                units_input.setRange(1, 1000)
                units_input.setValue(32)
                self.layer_param_inputs["units"] = units_input
                
                activation_label = QLabel("Activation:")
                activation_combo = QComboBox()
                activation_combo.addItems(["relu", "sigmoid", "tanh", "softmax"])
                self.layer_param_inputs["activation"] = activation_combo
                
                params_layout.addWidget(units_label)
                params_layout.addWidget(units_input)
                params_layout.addWidget(activation_label)
                params_layout.addWidget(activation_combo)
            
            elif layer_type == "Conv2D":
                filters_label = QLabel("Filters:")
                filters_input = QSpinBox()
                filters_input.setRange(1, 1000)
                filters_input.setValue(32)
                self.layer_param_inputs["filters"] = filters_input
                
                kernel_label = QLabel("Kernel Size:")
                kernel_input = QLineEdit()
                kernel_input.setText("3, 3")
                self.layer_param_inputs["kernel_size"] = kernel_input
                
                params_layout.addWidget(filters_label)
                params_layout.addWidget(filters_input)
                params_layout.addWidget(kernel_label)
                params_layout.addWidget(kernel_input)
            
            elif layer_type == "Dropout":
                rate_label = QLabel("Dropout Rate:")
                rate_input = QDoubleSpinBox()
                rate_input.setRange(0.0, 1.0)
                rate_input.setValue(0.5)
                rate_input.setSingleStep(0.1)
                self.layer_param_inputs["rate"] = rate_input
                
                params_layout.addWidget(rate_label)
                params_layout.addWidget(rate_input)
        
        type_combo.currentIndexChanged.connect(update_params)
        update_params()  # Initial update
        
        params_group.setLayout(params_layout)
        layout.addWidget(params_group)
        
        # Buttons
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Layer")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        def add_layer():
            layer_type = type_combo.currentText()
            
            # Collect parameters
            layer_params = {}
            for param_name, widget in self.layer_param_inputs.items():
                if isinstance(widget, QSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QComboBox):
                    layer_params[param_name] = widget.currentText()
                elif isinstance(widget, QLineEdit):
                    # Handle kernel size or other tuple-like inputs
                    if param_name == "kernel_size":
                        layer_params[param_name] = tuple(map(int, widget.text().split(',')))
            
            self.layer_config.append({
                "type": layer_type,
                "params": layer_params
            })
            
            dialog.accept()
        
        add_btn.clicked.connect(add_layer)
        cancel_btn.clicked.connect(dialog.reject)
        
        dialog.exec()
    
    def create_training_params_group(self):
        """Create group for neural network training parameters"""
        group = QGroupBox("Training Parameters")
        layout = QVBoxLayout()
        
        # Batch size
        batch_layout = QHBoxLayout()
        batch_layout.addWidget(QLabel("Batch Size:"))
        self.batch_size_spin = QSpinBox()
        self.batch_size_spin.setRange(1, 1000)
        self.batch_size_spin.setValue(32)
        batch_layout.addWidget(self.batch_size_spin)
        layout.addLayout(batch_layout)
        
        # Epochs
        epochs_layout = QHBoxLayout()
        epochs_layout.addWidget(QLabel("Epochs:"))
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 1000)
        self.epochs_spin.setValue(10)
        epochs_layout.addWidget(self.epochs_spin)
        layout.addLayout(epochs_layout)
        
        # Learning rate
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("Learning Rate:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.0001, 1.0)
        self.lr_spin.setValue(0.001)
        self.lr_spin.setSingleStep(0.001)
        lr_layout.addWidget(self.lr_spin)
        layout.addLayout(lr_layout)
        
        group.setLayout(layout)
        return group
    
    def create_cnn_controls(self):
        """Create controls for Convolutional Neural Network"""
        group = QGroupBox("CNN Architecture")
        layout = QVBoxLayout()
        
        # Placeholder for CNN-specific controls
        label = QLabel("CNN Controls (To be implemented)")
        layout.addWidget(label)
        
        group.setLayout(layout)
        return group
    
    def create_rnn_controls(self):
        """Create controls for Recurrent Neural Network"""
        group = QGroupBox("RNN Architecture")
        layout = QVBoxLayout()
        
        # Placeholder for RNN-specific controls
        label = QLabel("RNN Controls (To be implemented)")
        layout.addWidget(label)
        
        group.setLayout(layout)
        return group
    
    def train_neural_network(self):
        """Train the neural network with current configuration"""
        if not self.layer_config:
            self.show_error("Please add at least one layer to the network")
            return
        
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Prepare data for neural network
            if len(self.X_train.shape) == 1:
                X_train = self.X_train.reshape(-1, 1)
                X_test = self.X_test.reshape(-1, 1)
            else:
                X_train = self.X_train
                X_test = self.X_test
            
            # One-hot encode target for classification
            y_train = tf.keras.utils.to_categorical(self.y_train)
            y_test = tf.keras.utils.to_categorical(self.y_test)
            
            # Compile model
            optimizer = optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                          loss='categorical_crossentropy',
                          metrics=['accuracy'])
            
            # Train model
            history = model.fit(X_train, y_train,
                                batch_size=batch_size,
                                epochs=epochs,
                                validation_data=(X_test, y_test),
                                callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
            self.status_bar.showMessage("Neural Network Training Complete")
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
    
    def create_neural_network(self):
        """Create neural network based on current configuration"""
        model = models.Sequential()
        
        # Add layers based on configuration
        for layer_config in self.layer_config:
            layer_type = layer_config["type"]
            params = layer_config["params"]
            
            if layer_type == "Dense":
                model.add(layers.Dense(**params))
            elif layer_type == "Conv2D":
                # Add input shape for the first layer
                if len(model.layers) == 0:
                    params['input_shape'] = self.X_train.shape[1:]
                model.add(layers.Conv2D(**params))
            elif layer_type == "MaxPooling2D":
                model.add(layers.MaxPooling2D())
            elif layer_type == "Flatten":
                model.add(layers.Flatten())
            elif layer_type == "Dropout":
                model.add(layers.Dropout(**params))
        
        # Add output layer based on number of classes
        num_classes = len(np.unique(self.y_train))
        model.add(layers.Dense(num_classes, activation='softmax'))
                
        return model

   
        
    def train_neural_network(self):
        """Train the neural network"""
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Compile model
            optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                        loss='categorical_crossentropy',
                        metrics=['accuracy'])
            
            # Train model
            history = model.fit(self.X_train, self.y_train,
                              batch_size=batch_size,
                              epochs=epochs,
                              validation_data=(self.X_test, self.y_test),
                              callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
            
    def create_progress_callback(self):
        """Create callback for updating progress bar during training"""
        class ProgressCallback(tf.keras.callbacks.Callback):
            def __init__(self, progress_bar):
                super().__init__()
                self.progress_bar = progress_bar
                
            def on_epoch_end(self, epoch, logs=None):
                progress = int(((epoch + 1) / self.params['epochs']) * 100)
                self.progress_bar.setValue(progress)
                
        return ProgressCallback(self.progress_bar)
        
    def update_visualization(self, y_pred):
        """Update the visualization with current results"""
        self.figure.clear()
        
        # Create appropriate visualization based on data
        if len(np.unique(self.y_test)) > 10:  # Regression
            ax = self.figure.add_subplot(111)
            ax.scatter(self.y_test, y_pred)
            ax.plot([self.y_test.min(), self.y_test.max()],
                   [self.y_test.min(), self.y_test.max()],
                   'r--', lw=2)
            ax.set_xlabel("Actual Values")
            ax.set_ylabel("Predicted Values")
            
        else:  # Classification
            if self.X_train.shape[1] > 2:  # Use PCA for visualization
                pca = PCA(n_components=2)
                X_test_2d = pca.fit_transform(self.X_test)
                
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_test_2d[:, 0], X_test_2d[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
                
            else:  # Direct 2D visualization
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(self.X_test[:, 0], self.X_test[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
        
        self.canvas.draw()
        
    def update_metrics(self, y_pred):
        """Update metrics display"""
        metrics_text = "Model Performance Metrics:\n\n"
        
        # Calculate appropriate metrics based on problem type
        if len(np.unique(self.y_test)) > 10:  # Regression
            mse = mean_squared_error(self.y_test, y_pred)
            rmse = np.sqrt(mse)
            r2 = self.current_model.score(self.X_test, self.y_test)
            
            metrics_text += f"Mean Squared Error: {mse:.4f}\n"
            metrics_text += f"Root Mean Squared Error: {rmse:.4f}\n"
            metrics_text += f"R² Score: {r2:.4f}"
            
        else:  # Classification
            accuracy = accuracy_score(self.y_test, y_pred)
            conf_matrix = confusion_matrix(self.y_test, y_pred)
            
            metrics_text += f"Accuracy: {accuracy:.4f}\n\n"
            metrics_text += "Confusion Matrix:\n"
            metrics_text += str(conf_matrix)
        
        self.metrics_text.setText(metrics_text)
        
    def plot_training_history(self, history):
        """Plot neural network training history"""
        self.figure.clear()
        
        # Plot training & validation accuracy
        ax1 = self.figure.add_subplot(211)
        ax1.plot(history.history['accuracy'])
        ax1.plot(history.history['val_accuracy'])
        ax1.set_title('Model Accuracy')
        ax1.set_ylabel('Accuracy')
        ax1.set_xlabel('Epoch')
        ax1.legend(['Train', 'Test'])
        
        # Plot training & validation loss
        ax2 = self.figure.add_subplot(212)
        ax2.plot(history.history['loss'])
        ax2.plot(history.history['val_loss'])
        ax2.set_title('Model Loss')
        ax2.set_ylabel('Loss')
        ax2.set_xlabel('Epoch')
        ax2.legend(['Train', 'Test'])
        
        self.figure.tight_layout()
        self.canvas.draw()

    
    
    def train_pca(self):
        try:
            n_components = self.pca_widgets["n_components"].value()
            whiten = self.pca_widgets["whiten"].isChecked()

            pca = PCA(n_components=n_components, whiten=whiten)
            X_pca = pca.fit_transform(self.X_train)
            self.X_train_pca = X_pca
            self.pca_model = pca

            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.plot(np.cumsum(pca.explained_variance_ratio_), marker='o')
            ax.set_title("Cumulative Explained Variance")
            ax.set_xlabel("Number of Components")
            ax.set_ylabel("Explained Variance Ratio")
            self.canvas.draw()

            self.status_bar.showMessage("PCA training complete")

        except Exception as e:
            self.show_error(f"PCA Error: {str(e)}")
    
    def train_lda(self):
        try:
            n_components = self.lda_widgets["n_components"].value()

            from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
            lda = LDA(n_components=n_components)
            X_lda = lda.fit_transform(self.X_train, self.y_train)
            
            self.X_train_lda = X_lda
            self.lda_model = lda

            # Visualization (2D için örnek)
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            scatter = ax.scatter(X_lda[:, 0], np.zeros_like(self.y_train), c=self.y_train, cmap='viridis')
            self.figure.colorbar(scatter)
            ax.set_title("LDA Projection (1D)")
            self.canvas.draw()

            self.status_bar.showMessage("LDA training complete")

        except Exception as e:
            self.show_error(f"LDA Error: {str(e)}")
    
    def train_tsne(self):
        try:
            from sklearn.manifold import TSNE

            n_components = self.tsne_widgets["n_components"].value()
            perplexity = self.tsne_widgets["perplexity"].value()

            # t-SNE çalıştır
            tsne = TSNE(n_components=n_components, perplexity=perplexity, random_state=42)
            X_tsne = tsne.fit_transform(self.X_train)

            self.X_train_tsne = X_tsne
            self.tsne_model = tsne

            # Görselleştir
            self.figure.clear()

            if n_components == 2:
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_tsne[:, 0], X_tsne[:, 1], c=self.y_train, cmap='viridis')
                ax.set_title("t-SNE Projection (2D)")
            elif n_components == 3:
                from mpl_toolkits.mplot3d import Axes3D
                ax = self.figure.add_subplot(111, projection='3d')
                scatter = ax.scatter(X_tsne[:, 0], X_tsne[:, 1], X_tsne[:, 2], c=self.y_train, cmap='viridis')
                ax.set_title("t-SNE Projection (3D)")
            elif n_components == 1:
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_tsne[:, 0], np.zeros_like(self.y_train), c=self.y_train, cmap='viridis')
                ax.set_title("t-SNE Projection (1D)")
            else:
                ax = self.figure.add_subplot(111)
                ax.text(0.1, 0.5, "Only 1D, 2D, 3D visualizations supported.", fontsize=12)

            self.figure.colorbar(scatter)
            self.canvas.draw()

        except Exception as e:
            self.show_error(f"t-SNE Error: {str(e)}")

    def train_umap(self):
        try:
            import umap
            n_neighbors = self.umap_widgets["n_neighbors"].value()
            min_dist = self.umap_widgets["min_dist"].value()
            n_components = self.umap_widgets["n_components"].value()

            reducer = umap.UMAP(n_neighbors=n_neighbors, min_dist=min_dist, n_components=n_components)
            X_umap = reducer.fit_transform(self.X_train)

            self.X_train_umap = X_umap
            self.umap_model = reducer

            self.figure.clear()
            ax = self.figure.add_subplot(111)
            if n_components == 2:
                scatter = ax.scatter(X_umap[:, 0], X_umap[:, 1], c=self.y_train, cmap='viridis')
                self.figure.colorbar(scatter)
                ax.set_title("UMAP Projection (2D)")
            elif n_components == 1:
                ax.scatter(X_umap[:, 0], np.zeros_like(self.y_train), c=self.y_train, cmap='viridis')
                ax.set_title("UMAP Projection (1D)")
            self.canvas.draw()

            self.status_bar.showMessage("UMAP training complete")

        except Exception as e:
            self.show_error(f"UMAP Error: {str(e)}")
    
    def train_cv(self):
        try:
            from sklearn.model_selection import KFold, cross_val_score
            from sklearn.linear_model import LogisticRegression
            from sklearn.metrics import make_scorer, mean_squared_error

            if self.X_train is None or self.y_train is None:
                self.show_error("Please load a dataset first.")
                return

            k = self.cv_k_spin.value()
            selected_metric = self.cv_metric_combo.currentText()

            # Model (sınıflandırma örneği üzerinden ilerliyoruz)
            model = LogisticRegression(max_iter=1000)
            kf = KFold(n_splits=k, shuffle=True, random_state=42)

            # Skor fonksiyonunu belirle
            if selected_metric == "Accuracy":
                scoring = "accuracy"
            elif selected_metric == "MSE":
                scoring = make_scorer(mean_squared_error)
            elif selected_metric == "RMSE":
                # özel skor fonksiyonu tanımla
                scoring = make_scorer(lambda y_true, y_pred: mean_squared_error(y_true, y_pred, squared=False))
            else:
                scoring = "accuracy"  # fallback

            # Cross-validation'ı çalıştır
            scores = cross_val_score(model, self.X_train, self.y_train, cv=kf, scoring=scoring)

            mean_score = scores.mean()
            std_score = scores.std()

            # Ekranda göster
            self.metrics_text.setText(
                f"K-Fold Cross-Validation ({selected_metric})\n\n"
                f"Scores: {scores}\n"
                f"Mean {selected_metric}: {mean_score:.4f}\n"
                f"Standard Deviation: {std_score:.4f}"
            )
            self.status_bar.showMessage("Cross-Validation complete")

        except Exception as e:
            self.show_error(f"CV Error: {str(e)}")

    def run_elbow_method(self):
        try:
            from sklearn.cluster import KMeans

            max_k = self.kmeans_widgets["max_k_for_elbow"].value()

            inertias = []
            K = list(range(1, max_k + 1))

            for k in K:
                kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
                kmeans.fit(self.X_train)
                inertias.append(kmeans.inertia_)

            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.plot(K, inertias, marker='o')
            ax.set_xlabel("Number of Clusters (k)")
            ax.set_ylabel("Inertia")
            ax.set_title("Elbow Method for Optimal k")
            self.canvas.draw()

            self.status_bar.showMessage("Elbow Method plot complete")

        except Exception as e:
            self.show_error(f"Elbow Method Error: {str(e)}")
    def train_model(self, name, param_widgets):
        try:
            if name == "K-Means Parameters":
                from sklearn.cluster import KMeans

                n_clusters = param_widgets["n_clusters"].value()
                max_iter = param_widgets["max_iter"].value()
                n_init = param_widgets["n_init"].value()

                model = KMeans(n_clusters=n_clusters, max_iter=max_iter, n_init=n_init, random_state=42)
                model.fit(self.X_train)

                self.kmeans_model = model
                y_pred = model.predict(self.X_test)

                # === KAYIP FONKSİYONU HESABI ===
                try:
                    if len(np.unique(self.y_test)) > 10:  # Regresyon
                        selected_loss = self.regression_loss_combo.currentText()
                        
                        if selected_loss == "MSE":
                            loss = mean_squared_error(self.y_test, y_pred)
                        elif selected_loss == "MAE":
                            loss = mean_absolute_error(self.y_test, y_pred)
                        elif selected_loss == "Huber":
                            error = self.y_test - y_pred
                            delta = 1.0
                            loss = np.mean(np.where(np.abs(error) <= delta,
                                                    0.5 * error**2,
                                                    delta * (np.abs(error) - 0.5 * delta)))
                    else:  # Sınıflandırma
                        selected_loss = self.classification_loss_combo.currentText()
                        if selected_loss == "Cross-Entropy":
                            try:
                                y_proba = model.predict_proba(self.X_test)
                                loss = log_loss(self.y_test, y_proba)
                            except AttributeError:
                                loss = float('nan')
                        elif selected_loss == "Hinge":
                            y_binary = np.where(self.y_test == model.classes_[0], -1, 1)
                            y_pred_binary = np.where(y_pred == model.classes_[0], -1, 1)
                            loss = hinge_loss(y_binary, y_pred_binary)

                    # GUI'de göster
                    self.metrics_text.append(f"\nSelected Loss ({selected_loss}): {loss:.4f}")
                except Exception as e:
                    self.metrics_text.append(f"\nLoss hesaplama hatası: {str(e)}")


                self.update_visualization(y_pred)
                self.update_metrics(y_pred)
                self.status_bar.showMessage("K-Means training complete")
            elif name == "Support Vector Machine":
                from sklearn.svm import SVC, SVR

                kernel = param_widgets["kernel"].currentText()
                C = param_widgets["C"].value()
                degree = param_widgets["degree"].value()
                epsilon = param_widgets["epsilon"].value()

                is_regression = len(np.unique(self.y_train)) > 10

                if is_regression:
                    model = SVR(kernel=kernel, C=C, epsilon=epsilon)
                else:
                    model = SVC(kernel=kernel, C=C, degree=degree, probability=True)

                model.fit(self.X_train, self.y_train)
                self.current_model = model
                y_pred = model.predict(self.X_test)

                self.update_visualization(y_pred)
                self.update_metrics(y_pred)

                # LOSS hesapla
                try:
                    if is_regression:
                        selected_loss = self.regression_loss_combo.currentText()
                        if selected_loss == "MSE":
                            loss = mean_squared_error(self.y_test, y_pred)
                        elif selected_loss == "MAE":
                            loss = mean_absolute_error(self.y_test, y_pred)
                        elif selected_loss == "Huber":
                            error = self.y_test - y_pred
                            delta = 1.0
                            loss = np.mean(np.where(np.abs(error) <= delta,
                                                    0.5 * error**2,
                                                    delta * (np.abs(error) - 0.5 * delta)))
                    else:
                        selected_loss = self.classification_loss_combo.currentText()
                        if selected_loss == "Cross-Entropy":
                            try:
                                y_proba = model.predict_proba(self.X_test)
                                loss = log_loss(self.y_test, y_proba)
                            except AttributeError:
                                loss = float('nan')
                        elif selected_loss == "Hinge":
                            y_binary = np.where(self.y_test == model.classes_[0], -1, 1)
                            y_pred_binary = np.where(y_pred == model.classes_[0], -1, 1)
                            loss = hinge_loss(y_binary, y_pred_binary)

                    self.metrics_text.append(f"\nSelected Loss ({selected_loss}): {loss:.4f}")
                    self.status_bar.showMessage("SVM/SVR Training Complete")
                except Exception as e:
                    self.metrics_text.append(f"\nLoss hesaplama hatası: {str(e)}")
            elif name == "Naive Bayes":
                from sklearn.naive_bayes import GaussianNB

                var_smoothing = param_widgets["var_smoothing"].value()
                prior_option = param_widgets["priors"].currentText()

                if prior_option == "Uniform":
                    priors = None
                else:
                    priors = [0.5, 0.5]  # Şimdilik sabit

                model = GaussianNB(var_smoothing=var_smoothing, priors=priors)
                model.fit(self.X_train, self.y_train)
                self.current_model = model
                y_pred = model.predict(self.X_test)

                self.update_visualization(y_pred)
                self.update_metrics(y_pred)
            try:
                selected_loss = self.classification_loss_combo.currentText()
                if selected_loss == "Cross-Entropy":
                    y_proba = model.predict_proba(self.X_test)
                    loss = log_loss(self.y_test, y_proba)
                elif selected_loss == "Hinge":
                    y_binary = np.where(self.y_test == model.classes_[0], -1, 1)
                    y_pred_binary = np.where(y_pred == model.classes_[0], -1, 1)
                    loss = hinge_loss(y_binary, y_pred_binary)

                self.metrics_text.append(f"\nSelected Loss ({selected_loss}): {loss:.4f}")
                self.status_bar.showMessage("Naive Bayes Training Complete")
            except Exception as e:
                self.metrics_text.append(f"\nLoss hesaplama hatası: {str(e)}")
                

        
            

        except Exception as e:
            self.show_error(f"Model Training Error ({name}): {str(e)}")
    def train_kmeans(self):
        try:
            from sklearn.cluster import KMeans
            from sklearn.metrics import silhouette_score
            from sklearn.decomposition import PCA
            import plotly.express as px
            import pandas as pd

            if self.X_train is None or len(self.X_train) == 0:
                self.show_error("Please load a dataset first.")
                return

            # Parametreleri al
            n_clusters = self.kmeans_widgets["n_clusters"].value()
            max_iter = self.kmeans_widgets["max_iter"].value()
            n_init = self.kmeans_widgets["n_init"].value()

            if n_clusters >= len(self.X_train):
                self.show_error(f"Number of clusters ({n_clusters}) must be less than number of samples ({len(self.X_train)}).")
                return

            # KMeans modeli
            model = KMeans(n_clusters=n_clusters, max_iter=max_iter, n_init=n_init, random_state=42)
            labels = model.fit_predict(self.X_train)

            # Silhouette skorunu hesapla
            score = silhouette_score(self.X_train, labels)

            # PCA ile 2D'ye indir
            X_2d = PCA(n_components=2).fit_transform(self.X_train)

            # DataFrame oluştur (plotly için)
            df = pd.DataFrame({
                "X1": X_2d[:, 0],
                "X2": X_2d[:, 1],
                "Cluster": labels.astype(str)
            })

            fig = px.scatter(df, x="X1", y="X2", color="Cluster",
                            title=f"KMeans Clustering (Silhouette Score: {score:.3f})")
            fig.update_traces(marker=dict(size=6))
            fig.show()

            self.metrics_text.setText(f"Silhouette Score: {score:.4f}")
            self.status_bar.showMessage(f"KMeans complete | Silhouette Score: {score:.4f}")

        except Exception as e:
            self.show_error(f"KMeans Error: {str(e)}")







        
    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)

def main():
    """Main function to start the application"""
    app = QApplication(sys.argv)
    window = MLCourseGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
